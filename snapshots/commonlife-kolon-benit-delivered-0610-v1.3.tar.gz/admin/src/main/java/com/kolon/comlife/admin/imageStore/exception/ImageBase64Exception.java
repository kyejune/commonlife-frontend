package com.kolon.comlife.admin.imageStore.exception;

public class ImageBase64Exception extends Exception {

    public ImageBase64Exception(String msg ) {
        super( msg );
    }
}
