package com.kolon.comlife.common.paginate;

public abstract interface PaginationRenderer
{
    public abstract String renderPagination(PaginateInfo paramPaginationInfo, String paramString);
}
