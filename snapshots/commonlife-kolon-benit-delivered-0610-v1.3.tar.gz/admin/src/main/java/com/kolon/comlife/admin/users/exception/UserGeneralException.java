package com.kolon.comlife.admin.users.exception;

public class UserGeneralException extends  Exception {

    public UserGeneralException(String message) {
        super(message);
    }
}
