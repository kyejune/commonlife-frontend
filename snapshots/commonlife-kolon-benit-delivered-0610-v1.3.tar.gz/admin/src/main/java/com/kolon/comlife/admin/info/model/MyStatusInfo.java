package com.kolon.comlife.admin.info.model;

public class MyStatusInfo {
    int myStatusIdx;
    String myStatusNm;

    public int getMyStatusIdx() {
        return myStatusIdx;
    }

    public void setMyStatusIdx(int myStatusIdx) {
        this.myStatusIdx = myStatusIdx;
    }

    public String getMyStatusNm() {
        return myStatusNm;
    }

    public void setMyStatusNm(String myStatusNm) {
        this.myStatusNm = myStatusNm;
    }
}
