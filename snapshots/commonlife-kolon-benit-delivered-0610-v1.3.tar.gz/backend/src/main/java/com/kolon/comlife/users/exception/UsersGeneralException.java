package com.kolon.comlife.users.exception;

public class UsersGeneralException extends Exception {

    public UsersGeneralException(String message) {
        super(message);
    }
}
