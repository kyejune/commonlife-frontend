package com.kolon.comlife.push.service;

import java.util.HashMap;

public interface PushService {
    int register(HashMap params);
}
