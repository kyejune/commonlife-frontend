package com.kolon.comlife.iot.model;

public class EnergyInfo extends IotBaseInfo {
    public EnergyInfo() {
        super();
    }
}
