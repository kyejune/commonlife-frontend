package com.kolon.comlife.iot.exception;

public class IotInfoNoDataException extends Exception {
    public IotInfoNoDataException() {
    }

    public IotInfoNoDataException(String message) {
        super(message);
    }
}
