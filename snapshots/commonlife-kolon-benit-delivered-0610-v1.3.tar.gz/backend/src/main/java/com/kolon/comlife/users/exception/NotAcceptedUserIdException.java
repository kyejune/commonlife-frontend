package com.kolon.comlife.users.exception;

public class NotAcceptedUserIdException extends Exception {

    public NotAcceptedUserIdException(String message) {
        super(message);
    }
}
