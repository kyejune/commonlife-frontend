package com.kolon.comlife.iot.exception;

public class IotControlOperationFailedException extends Exception {
    public IotControlOperationFailedException() {
    }

    public IotControlOperationFailedException(String message) {
        super(message);
    }
}
