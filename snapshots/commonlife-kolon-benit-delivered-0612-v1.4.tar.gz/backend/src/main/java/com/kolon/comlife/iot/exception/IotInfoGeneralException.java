package com.kolon.comlife.iot.exception;

public class IotInfoGeneralException extends Exception {
    public IotInfoGeneralException() {
    }

    public IotInfoGeneralException(String message) {
        super(message);
    }
}
