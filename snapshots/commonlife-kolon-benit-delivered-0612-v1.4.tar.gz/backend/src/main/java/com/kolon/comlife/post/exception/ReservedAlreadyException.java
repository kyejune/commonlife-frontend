package com.kolon.comlife.post.exception;

public class ReservedAlreadyException extends Exception {

    public ReservedAlreadyException() {
    }

    public ReservedAlreadyException(String message) {
        super(message);
    }

}
