package com.kolon.common.exception;

public class SmsException extends Exception {

    public SmsException(String message) {
        super( message );
    }
}
