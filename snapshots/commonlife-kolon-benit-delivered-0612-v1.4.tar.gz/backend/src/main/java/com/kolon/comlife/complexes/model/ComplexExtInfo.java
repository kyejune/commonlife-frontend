package com.kolon.comlife.complexes.model;

public class ComplexExtInfo extends ComplexInfo {
    // TODO: ComplexInfo 정보를 여기로... 옮기자
}
