package com.kolon.comlife.admin.info.exception;

public class InfoGeneralException extends Exception {

    public InfoGeneralException( String message ){
        super( message );
    }

}
