이 폴더에는 수정되지 않는 프렘워크/라이브러리 등의 자원이 위치합니다. resources 목록은 다음과 같습니다.
- inspinia_v2.7.1(ui framework)

사용자 추가 파일은 /webapp 폴더 하위에 위치하시기 바랍니다.
