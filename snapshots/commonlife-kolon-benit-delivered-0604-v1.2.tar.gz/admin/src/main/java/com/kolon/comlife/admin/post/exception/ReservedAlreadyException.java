package com.kolon.comlife.admin.post.exception;

public class ReservedAlreadyException extends Exception {

    public ReservedAlreadyException() {
    }

    public ReservedAlreadyException(String message) {
        super(message);
    }

}
