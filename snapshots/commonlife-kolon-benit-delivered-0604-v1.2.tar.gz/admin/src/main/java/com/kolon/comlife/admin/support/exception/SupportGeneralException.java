package com.kolon.comlife.admin.support.exception;

public class SupportGeneralException extends  Exception {

    public SupportGeneralException(String message) {
        super(message);
    }
}
