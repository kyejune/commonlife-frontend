package com.kolon.comlife.admin.complexes.model;

public class ComplexRegion {

    int clCmplxRgnId;
    String rgnNm;
    int dispOrder;


    public int getClCmplxRgnId() {
        return clCmplxRgnId;
    }

    public void setClCmplxRgnId(int clCmplxRgnId) {
        this.clCmplxRgnId = clCmplxRgnId;
    }

    public String getRgnNm() {
        return rgnNm;
    }

    public void setRgnNm(String rgnNm) {
        this.rgnNm = rgnNm;
    }

    public int getDispOrder() {
        return dispOrder;
    }

    public void setDispOrder(int dispOrder) {
        this.dispOrder = dispOrder;
    }
}
