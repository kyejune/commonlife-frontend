package com.kolon.comlife.common.model;

public class SimpleErrorInfo extends SimpleMsgInfo {
        public SimpleErrorInfo() {
        super();
    }

    public SimpleErrorInfo(String msg) {
        super(msg);
    }
}

