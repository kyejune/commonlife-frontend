package com.kolon.comlife.common.model;

public class SimpleMsgInfo {
    protected String msg;

    public SimpleMsgInfo() { };

    public SimpleMsgInfo(String msg) {
        this.msg = msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}

