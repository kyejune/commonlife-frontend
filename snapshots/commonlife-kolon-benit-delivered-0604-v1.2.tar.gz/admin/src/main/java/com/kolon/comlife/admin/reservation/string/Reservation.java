package com.kolon.comlife.admin.reservation.string;

public class Reservation {
    private static final String RESERVED = "RESERVED";
    private static final String PENDING = "PENDING";
    private static final String USER_CANCELED = "USER_CANCELED";
    private static final String ADMIN_CANCELED = "ADMIN_CANCELED";
}
