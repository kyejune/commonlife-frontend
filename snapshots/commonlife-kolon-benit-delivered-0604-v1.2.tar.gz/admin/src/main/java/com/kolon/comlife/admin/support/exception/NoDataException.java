package com.kolon.comlife.admin.support.exception;

public class NoDataException extends Exception {

    public NoDataException() {
    }

    public NoDataException(String message) {
        super(message);
    }

}
