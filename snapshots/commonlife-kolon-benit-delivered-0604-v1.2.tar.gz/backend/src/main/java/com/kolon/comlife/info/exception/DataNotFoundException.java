package com.kolon.comlife.info.exception;

public class DataNotFoundException extends Exception {

    public DataNotFoundException( String message ) {
        super( message );
    }
}
