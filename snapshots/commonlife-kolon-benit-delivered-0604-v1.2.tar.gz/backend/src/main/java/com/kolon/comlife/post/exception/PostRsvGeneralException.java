package com.kolon.comlife.post.exception;

public class PostRsvGeneralException extends Exception {

    public PostRsvGeneralException() {
    }

    public PostRsvGeneralException(String message) {
        super(message);
    }

}
