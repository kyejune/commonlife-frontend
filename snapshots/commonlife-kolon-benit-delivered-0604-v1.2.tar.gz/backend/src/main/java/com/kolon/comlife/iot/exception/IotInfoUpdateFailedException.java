package com.kolon.comlife.iot.exception;

public class IotInfoUpdateFailedException extends Exception {
    public IotInfoUpdateFailedException() {
    }

    public IotInfoUpdateFailedException(String message) {
        super(message);
    }
}
