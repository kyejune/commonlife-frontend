package com.kolon.comlife.users.exception;

public class KeyNotFoundException extends Exception {

    public KeyNotFoundException(String message ) {
        super( message );
    }
}
