package com.kolon.comlife.point.service;

import com.kolon.comlife.point.model.PointHistoryInfo;

public interface PointHistoryService {
    public int create(PointHistoryInfo info );
}
