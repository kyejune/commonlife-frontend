package com.kolon.comlife.iot.exception;

public class IotInvalidPathVariableException extends Exception {
    public IotInvalidPathVariableException() {
    }

    public IotInvalidPathVariableException(String message) {
        super(message);
    }
}
