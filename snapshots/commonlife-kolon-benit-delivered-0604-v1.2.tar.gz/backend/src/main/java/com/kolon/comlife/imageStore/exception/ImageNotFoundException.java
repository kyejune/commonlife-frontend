package com.kolon.comlife.imageStore.exception;

public class ImageNotFoundException extends Exception {

    public ImageNotFoundException(String msg ) {
        super( msg );
    }
}
