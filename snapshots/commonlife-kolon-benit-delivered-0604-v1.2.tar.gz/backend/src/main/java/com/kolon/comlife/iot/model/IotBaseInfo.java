package com.kolon.comlife.iot.model;

import com.kolon.comlife.common.model.SimpleMsgInfo;

public class IotBaseInfo extends SimpleMsgInfo {

    public IotBaseInfo() {
        super();
    }
}
