package com.kolon.comlife.admin.imageStore.exception;

public class ImageNotFoundException extends Exception {

    public ImageNotFoundException(String msg ) {
        super( msg );
    }
}
