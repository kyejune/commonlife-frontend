package com.kolon.comlife.admin.support.exception;

public class OperationFailedException extends Exception {

    public OperationFailedException() {
    }

    public OperationFailedException(String message) {
        super(message);
    }

}
