package com.kolon.common.admin.pagination;

public interface PaginationRenderer
{
    String renderPagination(PaginationInfo paramPaginationInfo, String paramString);
}
