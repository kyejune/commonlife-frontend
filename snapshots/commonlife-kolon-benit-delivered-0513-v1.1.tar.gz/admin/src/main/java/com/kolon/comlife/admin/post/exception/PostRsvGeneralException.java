package com.kolon.comlife.admin.post.exception;

public class PostRsvGeneralException extends Exception {

    public PostRsvGeneralException() {
    }

    public PostRsvGeneralException(String message) {
        super(message);
    }

}
