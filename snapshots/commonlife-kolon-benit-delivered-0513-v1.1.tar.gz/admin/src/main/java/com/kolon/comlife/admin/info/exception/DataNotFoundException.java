package com.kolon.comlife.admin.info.exception;

public class DataNotFoundException extends Exception {

    public DataNotFoundException( String message ) {
        super( message );
    }
}
