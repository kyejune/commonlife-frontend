
/**
 * 관리자 그룹 (슈퍼관리자 or 현장관리자)
 *
 * AdminInfo.java 의 상수 값과 동일하게 관리해야 합니다.
 */

export const ADMIN_GRP = {
    SUPER: "ADMIN_GRP_SUPER",
    COMPLEX: "ADMIN_GRP_COMPLEX"
};

