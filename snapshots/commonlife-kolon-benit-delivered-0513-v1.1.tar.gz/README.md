# commonlife-repo
## Link 
1. jira: https://hslab-team.atlassian.net/secure/RapidBoard.jspa?rapidView=3&projectKey=IOT
2. wiki: https://hslab-team.atlassian.net/wiki/spaces/IOT

## Directory 
1. /admin - 관리자 사이트의 Backend/Frontend 프로젝트 
2. /frontend - 사용자앱의 Frontend 프로젝트
3. /backend - 사용자앱의 Backend 프로젝트 

## Slack
- https://helloshop-kr.slack.com


## HISTORY 
1. 2018-05-13  KOLON BENITE 1차 소스 코드 전달 
