여기의 파일은 Postman Team Library에서 내보내기 한 파일입니다. API 백업 및 오토메이션을 위해 별도로저장합니다.
아래 파일들은 바로 수정하지 마시고, Postman에서 업

/postman/env/*
 - 환경변수

/postman/CommonLife.postman_collection.json
  - Common Life API 예제

/postman/CommonLife.TEST.postman_collection.json
  - Common Life API 자동화 테스트 케이스 스위트

/postman/Kolon N-Housing.postman_collection.json
 - IOK N-Housing API 예제