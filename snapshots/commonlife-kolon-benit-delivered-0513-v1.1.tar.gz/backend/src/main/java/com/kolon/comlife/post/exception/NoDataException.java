package com.kolon.comlife.post.exception;

public class NoDataException extends Exception {

    public NoDataException() {
    }

    public NoDataException(String message) {
        super(message);
    }

}
