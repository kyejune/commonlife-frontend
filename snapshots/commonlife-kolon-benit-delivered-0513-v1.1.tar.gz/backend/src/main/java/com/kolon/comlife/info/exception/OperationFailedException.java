package com.kolon.comlife.info.exception;

public class OperationFailedException extends Exception {

    public OperationFailedException() {
    }

    public OperationFailedException(String message) {
        super(message);
    }

}
