package com.kolon.comlife.iot.exception;

public class IotControlTimeoutException extends Exception {
    public IotControlTimeoutException() {
    }

    public IotControlTimeoutException(String message) {
        super(message);
    }
}
