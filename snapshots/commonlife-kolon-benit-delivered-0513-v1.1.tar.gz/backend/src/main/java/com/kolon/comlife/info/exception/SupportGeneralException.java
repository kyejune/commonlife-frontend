package com.kolon.comlife.info.exception;

public class SupportGeneralException extends  Exception {

    public SupportGeneralException(String message) {
        super(message);
    }
}
