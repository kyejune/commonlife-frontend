package com.kolon.comlife.iot.model;

public class IotSensorListInfo extends IotBaseInfo {
    public IotSensorListInfo() {
        super();
    }
}
