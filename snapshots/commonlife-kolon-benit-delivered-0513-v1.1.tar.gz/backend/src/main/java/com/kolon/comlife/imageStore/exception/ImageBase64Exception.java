package com.kolon.comlife.imageStore.exception;

public class ImageBase64Exception extends Exception {

    public ImageBase64Exception(String msg ) {
        super( msg );
    }
}
