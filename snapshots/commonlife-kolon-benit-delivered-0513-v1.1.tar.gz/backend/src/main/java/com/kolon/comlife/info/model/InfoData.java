package com.kolon.comlife.info.model;

import org.apache.ibatis.type.Alias;


public class InfoData {
    String infoKey;
    String imgSrc;
    String infoNm;

    public String getInfoKey() {
        return infoKey;
    }

    public void setInfoKey(String infoKey) {
        this.infoKey = infoKey;
    }

    public String getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getInfoNm() {
        return infoNm;
    }

    public void setInfoNm(String infoNm) {
        this.infoNm = infoNm;
    }
}
